package example;

public class Example {

    public static String join(String... args) {
        return String.join(" ", args);
    }
    
}
